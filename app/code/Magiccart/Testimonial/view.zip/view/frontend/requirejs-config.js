var config = {
	map: {
		'*': {
			testimonial: "Magiccart_Testimonial/js/testimonial",
		},
	}
};
